import React, { useState } from 'react';
import { X, Eye, AlertCircle, ShoppingCart, Download, Copy, Check, Receipt } from 'lucide-react';
import { motion } from 'motion/react';

interface ReceiptModalProps {
  selectedItem: any;
  setSelectedItem: (item: any) => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ selectedItem, setSelectedItem }) => {
  const [showSecret, setShowSecret] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  if (!selectedItem) return null;
  
  const isPurchase = !selectedItem.type?.includes('topup');

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
        className="bg-surface border border-separator w-full max-w-[580px] rounded-3xl relative overflow-hidden flex flex-col max-h-[90vh] shadow-2xl text-label"
      >
        {/* Header */}
        <div className="pt-5 px-6 pb-4 flex items-center justify-between border-b border-separator">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-surface-2 border border-separator flex items-center justify-center text-link">
              <Receipt className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-label tracking-tight">
                {isPurchase ? 'ใบเสร็จการสั่งซื้อ' : 'ใบเสร็จการเติมเงิน'}
              </h3>
              <p className="text-xs font-sans tabular-nums text-label-2">
                {selectedItem.billNumber || `#${(selectedItem.id || 'TX000000').substring(0, 10).toUpperCase()}`}
              </p>
            </div>
          </div>

          <button 
            onClick={() => setSelectedItem(null)}
            className="w-8 h-8 bg-surface-2 hover:bg-surface border border-separator flex items-center justify-center text-label-2 hover:text-label transition-all rounded-full cursor-pointer active:scale-95"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="overflow-y-auto p-5 sm:p-6 scrollbar-hide flex-1 space-y-4">
          {/* Summary Box */}
          <div className="bg-surface-2 border border-separator p-4.5 rounded-2xl space-y-2.5">
            <h4 className="text-xs font-medium text-label-3">ข้อมูลการทำรายการ</h4>
            
            <div className="flex items-center justify-between text-xs sm:text-sm">
              <span className="text-label-2">วันที่ทำรายการ</span>
              <span className="text-label font-medium">
                {new Date(selectedItem.date || selectedItem.timestamp || new Date()).toLocaleString('th-TH')}
              </span>
            </div>

            <div className="flex items-center justify-between text-xs sm:text-sm">
              <span className="text-label-2">ช่องทาง / บริการ</span>
              <span className="text-label font-medium">
                {isPurchase ? (selectedItem.productName || 'สินค้าดิจิทัล') : (selectedItem.method || 'เติมเงินเข้าระบบ')}
              </span>
            </div>

            <div className="flex items-center justify-between pt-2.5 border-t border-separator">
              <span className="text-label font-semibold text-sm">ยอดเงินรวม</span>
              <span className="text-xl font-semibold text-link font-sans tabular-nums">
                ฿{(selectedItem.money || selectedItem.amount || selectedItem.price || 0).toLocaleString()}
              </span>
            </div>
          </div>

          {/* Secret / Key Delivery Box if purchase */}
          {isPurchase && selectedItem.secretData && (
            <div className="bg-surface-2 border border-separator p-4.5 rounded-2xl">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-xs font-medium text-label-3">ข้อมูลสินค้า / คีย์ลับ</h4>
                
                {showSecret && (
                  <div className="flex gap-2">
                    <button 
                      onClick={() => {
                        navigator.clipboard.writeText(selectedItem.secretData);
                        setIsCopied(true);
                        setTimeout(() => setIsCopied(false), 2000);
                      }}
                      className="text-xs font-medium text-link hover:text-accent-hover bg-surface border border-separator px-3 py-1 rounded-full flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      {isCopied ? <Check className="w-3.5 h-3.5 text-success" /> : <Copy className="w-3.5 h-3.5 text-link" />}
                      <span>{isCopied ? 'คัดลอกแล้ว' : 'คัดลอก'}</span>
                    </button>
                    <button 
                      onClick={() => {
                        const blob = new Blob([selectedItem.secretData], { type: 'text/plain;charset=utf-8' });
                        const url = URL.createObjectURL(blob);
                        const link = document.createElement('a');
                        link.href = url;
                        link.download = `key_${(selectedItem.productName || 'product').replace(/[^\wก-๙]/g, '_')}.txt`;
                        link.click();
                        URL.revokeObjectURL(url);
                      }}
                      className="text-xs font-medium text-label-2 hover:text-label bg-surface border border-separator px-3 py-1 rounded-full flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>ดาวน์โหลด</span>
                    </button>
                  </div>
                )}
              </div>

              {!showSecret ? (
                <button 
                  onClick={() => setShowSecret(true)}
                  className="w-full py-2.5 bg-surface hover:bg-surface-2 text-link border border-separator text-xs font-medium rounded-full flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-98"
                >
                  <Eye className="w-4 h-4" />
                  <span>คลิกเพื่อดูข้อมูลสินค้า / รหัสคีย์</span>
                </button>
              ) : (
                <div className="bg-surface border border-separator p-3.5 text-xs sm:text-sm font-sans tabular-nums text-label whitespace-pre-wrap max-h-48 overflow-y-auto w-full break-all rounded-2xl select-all">
                  {selectedItem.secretData}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-separator bg-surface">
          <button 
            onClick={() => setSelectedItem(null)}
            className="w-full py-2.5 bg-accent hover:bg-accent-hover text-white text-xs font-medium rounded-full transition-all active:scale-[0.98] cursor-pointer shadow-sm"
          >
            ปิดหน้าต่าง
          </button>
        </div>
      </motion.div>
    </div>
  );
};
