import React from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, FileText } from 'lucide-react';
import Markdown from 'react-markdown';

interface PageViewProps {
  page: { title: string; content: string; slug: string } | null;
  onBack: () => void;
}

export const PageView: React.FC<PageViewProps> = ({ page, onBack }) => {
  if (!page) return null;

  return (
    <div className="w-full max-w-4xl mx-auto py-6 sm:py-8 px-4 sm:px-6">
      <div className="flex items-center gap-2 mb-6 sm:mb-8 text-sm">
        <button
          type="button"
          onClick={onBack}
          aria-label="กลับหน้าหลัก"
          className="text-label-2 hover:text-label transition-colors flex items-center gap-1.5 font-medium px-4 py-2 bg-surface hover:bg-surface-2 border border-separator rounded-full cursor-pointer active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>กลับหน้าหลัก</span>
        </button>
      </div>

      <motion.article 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25 }}
        className="bg-surface border border-separator overflow-hidden p-6 sm:p-10 md:p-12 min-h-[60vh] rounded-3xl shadow-xl"
      >
        <header className="border-b border-separator pb-6 mb-8 flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-surface-2 border border-separator flex items-center justify-center text-accent shrink-0">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl md:text-3xl font-semibold text-label tracking-tight">
              {page.title.replace(/^#+\s*/, '')}
            </h1>
          </div>
        </header>
        
        <div className="markdown-body text-label leading-relaxed">
          <Markdown>{page.content || '*ไม่มีเนื้อหา*'}</Markdown>
        </div>
      </motion.article>
    </div>
  );
};

export default PageView;
