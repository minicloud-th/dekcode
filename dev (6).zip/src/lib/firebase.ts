import { initializeApp, getApps, getApp } from "firebase/app";
import {
  getAuth,
  GoogleAuthProvider,
  GithubAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail,
  updateProfile,
  type User as FirebaseUser,
} from "firebase/auth";

// Web app's Firebase configuration provided by the user
const firebaseConfig = {
  apiKey: "AIzaSyBiygb1RUjqCK2G_m4FCkQ_HdGuYW03Uog",
  authDomain: "zenone-eaf64.firebaseapp.com",
  projectId: "zenone-eaf64",
  storageBucket: "zenone-eaf64.firebasestorage.app",
  messagingSenderId: "741627796817",
  appId: "1:741627796817:web:669db8553f1849e8544770",
};

// Initialize Firebase safely
export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);

// OAuth Providers
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: "select_account" });

export const githubProvider = new GithubAuthProvider();

/**
 * Sign in with Google Popup (Real OAuth)
 */
export async function signInWithGoogle(): Promise<FirebaseUser> {
  const result = await signInWithPopup(auth, googleProvider);
  return result.user;
}

/**
 * Sign in with GitHub Popup (Real OAuth)
 */
export async function signInWithGithub(): Promise<FirebaseUser> {
  const result = await signInWithPopup(auth, githubProvider);
  return result.user;
}

/**
 * Sign in with Email and Password
 */
export async function signInEmail(email: string, pass: string): Promise<FirebaseUser> {
  const cred = await signInWithEmailAndPassword(auth, email, pass);
  return cred.user;
}

/**
 * Sign up with Email and Password
 */
export async function signUpEmail(email: string, pass: string, displayName?: string): Promise<FirebaseUser> {
  const cred = await createUserWithEmailAndPassword(auth, email, pass);
  if (displayName && cred.user) {
    await updateProfile(cred.user, { displayName });
  }
  return cred.user;
}

/**
 * Send password reset email
 */
export async function resetPassword(email: string): Promise<void> {
  await sendPasswordResetEmail(auth, email);
}

/**
 * Sign out of Firebase
 */
export async function logOut(): Promise<void> {
  await signOut(auth);
}

/**
 * Subscribe to Firebase Auth state changes
 */
export function onAuthChange(callback: (user: FirebaseUser | null) => void) {
  return onAuthStateChanged(auth, callback);
}
