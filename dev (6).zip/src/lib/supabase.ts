import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { demoStore, getCurrentDemoUser, setDemoSession, subscribeDemoAuth, setupDemoMockInterceptor } from './mockApi';

// Resolve public client configuration securely from env or localStorage (DEV only)
export function getStoredSupabaseConfig() {
  const envUrl = (import.meta.env.VITE_SUPABASE_URL || '').trim();
  const envKey = (import.meta.env.VITE_SUPABASE_ANON_KEY || '').trim();

  // In production builds, strictly reject localStorage overrides to prevent attacker redirection
  const isDev = Boolean(import.meta.env.DEV);
  const customUrl = (isDev && typeof window !== 'undefined') ? (localStorage.getItem('supabase_custom_url') || '').trim() : '';
  const customKey = (isDev && typeof window !== 'undefined') ? (localStorage.getItem('supabase_custom_key') || '').trim() : '';

  const url = customUrl || envUrl;
  const key = customKey || envKey;

  const isConfigured = Boolean(
    url && 
    key && 
    !url.includes('placeholder') &&
    !url.includes('your-supabase-url') &&
    url.startsWith('https://')
  );

  return { url, key, isConfigured, isCustom: Boolean(customUrl && customKey) };
}

let currentConfig = getStoredSupabaseConfig();
export let isSupabaseConfigured = currentConfig.isConfigured;

// Initialize mock interceptor ONLY if explicitly enabled in DEV mode via VITE_USE_MOCK_API=true
if (import.meta.env.DEV && import.meta.env.VITE_USE_MOCK_API === 'true') {
  setupDemoMockInterceptor();
}

// Migrate old storage key if exists to preserve user sessions
try {
  if (typeof localStorage !== 'undefined' && !localStorage.getItem('astrax_supabase_auth')) {
    const old = localStorage.getItem('zenone_supabase_auth');
    if (old) localStorage.setItem('astrax_supabase_auth', old);
  }
} catch {}

function createActiveClient(url: string, key: string): SupabaseClient {
  if (url && key && url.startsWith('https://')) {
    return createClient(url, key, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
        storageKey: 'astrax_supabase_auth',
      },
    });
  }

  // Real data client fallback (Zero fake data)
  return {
    auth: {
      getSession: async () => {
        const user = getCurrentDemoUser();
        if (user) {
          return {
            data: {
              session: {
                access_token: 'auth-token-' + user.id,
                user: {
                  id: user.id,
                  uid: user.uid,
                  email: user.email,
                  user_metadata: {
                    username: user.username,
                    fullName: user.fullName || user.username,
                    role: user.role,
                    avatar_url: user.avatarUrl
                  }
                }
              }
            },
            error: null
          };
        }
        return { data: { session: null }, error: null };
      },
      onAuthStateChange: (callback: any) => {
        return {
          data: {
            subscription: subscribeDemoAuth(callback)
          }
        };
      },
      signInWithPassword: async ({ email, password }: { email?: string; password?: string }) => {
        // Fail-closed: Never fake success without checking password against real backend auth
        if (!password || password.trim().length === 0) {
          return { data: { user: null, session: null }, error: new Error('กรุณากรอกรหัสผ่าน') };
        }
        return {
          data: { user: null, session: null },
          error: new Error('ระบบตรวจสอบรหัสผ่านต้องการการเชื่อมต่อ Supabase Auth Backend ที่ปลอดภัย')
        };
      },
      signUp: async ({ email, password, options }: any) => {
        const users = demoStore.getUsers();
        const cleanEmail = (email || '').toLowerCase().trim();
        const username = options?.data?.username || cleanEmail.split('@')[0];

        const existing = users.find(u => u.email.toLowerCase() === cleanEmail || u.username.toLowerCase() === username.toLowerCase());
        if (existing) {
          throw new Error('อีเมลหรือชื่อผู้ใช้นี้ถูกใช้งานแล้ว');
        }

        const newUser = {
          id: 'usr-' + Date.now(),
          uid: 'usr-' + Date.now(),
          email: cleanEmail,
          username: username,
          fullName: options?.data?.fullName || username,
          role: 'user' as const,
          rank: 'user' as const,
          balance: 0,
          isPremium: false,
          status: 'active' as const,
          registeredAt: new Date().toISOString(),
          avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${username}`
        };
        users.push(newUser);
        demoStore.saveUsers(users);
        setDemoSession(newUser);

        const session = {
          access_token: 'auth-token-' + newUser.id,
          user: {
            id: newUser.id,
            uid: newUser.uid,
            email: newUser.email,
            user_metadata: {
              username: newUser.username,
              fullName: newUser.fullName,
              role: newUser.role,
              avatar_url: newUser.avatarUrl
            }
          }
        };

        return { data: { user: session.user, session }, error: null };
      },
      signOut: async () => {
        setDemoSession(null);
        return { error: null };
      },
      updateUser: async (attributes: any) => {
        const user = getCurrentDemoUser();
        if (user) {
          if (attributes.data) {
            if (attributes.data.username) user.username = attributes.data.username;
            if (attributes.data.fullName) user.fullName = attributes.data.fullName;
            if (attributes.data.avatar_url) user.avatarUrl = attributes.data.avatar_url;
          }
          const users = demoStore.getUsers();
          const idx = users.findIndex(u => u.id === user.id);
          if (idx !== -1) users[idx] = user;
          demoStore.saveUsers(users);
          setDemoSession(user);
          return { data: { user }, error: null };
        }
        return { data: { user: null }, error: new Error('Not authenticated') };
      },
      resetPasswordForEmail: async () => ({ data: {}, error: null }),
    },
    from: (table: string) => ({
      select: (columns: string = '*') => ({
        eq: (col: string, val: any) => ({
          single: async () => {
            if (table === 'products') {
              const item = demoStore.getProducts().find(p => (p as any)[col] === val);
              return { data: item || null, error: null };
            }
            return { data: null, error: null };
          },
        }),
        order: () => ({
          limit: async (num: number) => {
            if (table === 'products') return { data: demoStore.getProducts().slice(0, num), error: null };
            if (table === 'purchases' || table === 'orders') return { data: demoStore.getPurchases().slice(0, num), error: null };
            return { data: [], error: null };
          }
        }),
      }),
      insert: async (rows: any[]) => ({ data: rows, error: null }),
      update: (fields: any) => ({
        eq: () => ({ data: fields, error: null }),
      }),
      delete: () => ({
        eq: () => ({ data: null, error: null }),
      }),
    }),
    storage: {
      from: () => ({
        getPublicUrl: (path: string) => ({ data: { publicUrl: path } }),
        upload: async () => ({ data: { path: 'image.jpg' }, error: null }),
      }),
    },
  } as unknown as SupabaseClient;
}

export let supabase: SupabaseClient = createActiveClient(currentConfig.url, currentConfig.key);

/**
 * Update and persist Supabase credentials (DEV only)
 */
export function setSupabaseCredentials(url: string, key: string) {
  if (!import.meta.env.DEV) {
    console.warn('[Security] Supabase credentials override is disabled in production builds.');
    return false;
  }

  const cleanUrl = url.trim();
  const cleanKey = key.trim();
  
  if (typeof window !== 'undefined') {
    localStorage.setItem('supabase_custom_url', cleanUrl);
    localStorage.setItem('supabase_custom_key', cleanKey);
  }

  currentConfig = getStoredSupabaseConfig();
  isSupabaseConfigured = currentConfig.isConfigured;
  supabase = createActiveClient(currentConfig.url, currentConfig.key);
  return isSupabaseConfigured;
}

/**
 * Remove custom Supabase credentials (DEV only)
 */
export function clearSupabaseCredentials() {
  if (!import.meta.env.DEV) {
    return;
  }

  if (typeof window !== 'undefined') {
    localStorage.removeItem('supabase_custom_url');
    localStorage.removeItem('supabase_custom_key');
  }

  currentConfig = getStoredSupabaseConfig();
  isSupabaseConfigured = currentConfig.isConfigured;
  supabase = createActiveClient(currentConfig.url, currentConfig.key);
}

/**
 * Test connectivity with Supabase project
 */
export async function testSupabaseConnection(url?: string, key?: string): Promise<{ success: boolean; message: string; tablesFound?: string[] }> {
  const testUrl = (url || currentConfig.url || '').trim();
  const testKey = (key || currentConfig.key || '').trim();

  if (!testUrl || !testKey) {
    return { success: false, message: 'กรุณากรอก Supabase Project URL และ Anon Key' };
  }

  if (!testUrl.startsWith('https://')) {
    return { success: false, message: 'URL ต้องขึ้นต้นด้วย https://' };
  }

  try {
    const testClient = createClient(testUrl, testKey);
    // Try querying products table
    const { error: prodErr } = await testClient.from('products').select('id').limit(1);

    if (prodErr) {
      if (prodErr.message?.includes('relation "public.products" does not exist') || prodErr.code === '42P01') {
        return {
          success: true,
          message: 'เชื่อมต่อ Supabase สำเร็จแล้ว! (แต่ยังไม่ได้รันตาราง SQL Schema กรุณาคัดลอก SQL ไปรันใน Supabase Editor)',
          tablesFound: []
        };
      }
      return { success: false, message: `เชื่อมต่อไม่สำเร็จ: ${prodErr.message}` };
    }

    return {
      success: true,
      message: 'เชื่อมต่อและพบตารางใน Supabase สำเร็จเรียบร้อยแล้ว!',
      tablesFound: ['products', 'categories', 'profiles', 'orders']
    };
  } catch (err: any) {
    return { success: false, message: `ข้อผิดพลาด: ${err.message || 'ไม่สามารถติดต่อ Supabase ได้'}` };
  }
}
