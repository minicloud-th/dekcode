import React, { Component, ErrorInfo, ReactNode } from "react";
import { AlertTriangle, RefreshCw } from "lucide-react";

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    // Suppress external browser extension script errors
    if (
      error &&
      error.message &&
      (error.message.includes("Cannot set property fetch") ||
       error.message.includes("chrome-extension://") ||
       error.stack?.includes("chrome-extension://"))
    ) {
      return { hasError: false, error: null };
    }
    // Update state so the next render will show the fallback UI.
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
    fetch('/api/log_error', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'react_error', message: error.message, stack: error.stack, componentStack: errorInfo.componentStack })
    }).catch(console.log);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-bg text-label flex flex-col items-center justify-center p-6 text-center">
          <div className="w-20 h-20 bg-danger/10 border border-danger/20 rounded-full flex items-center justify-center mb-6">
            <AlertTriangle className="w-10 h-10 text-danger" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-semibold mb-3 text-label">ระบบเกิดข้อผิดพลาด</h1>
          <p className="text-label-2 mb-8 max-w-md text-sm">
            ขออภัย มีบางอย่างผิดปกติที่ฝั่งไคลเอนต์
            กรุณาลองรีเฟรชหน้าเว็บอีกครั้ง
          </p>
          <div className="bg-surface p-5 border border-separator text-left w-full max-w-2xl mb-8 overflow-auto rounded-3xl">
            <code className="text-sm text-danger font-mono">
              {this.state.error?.message}
            </code>
          </div>
          <button
            type="button"
            onClick={this.handleReset}
            className="flex items-center gap-2 bg-accent hover:bg-accent-hover text-white px-8 py-3 font-medium transition-all rounded-full cursor-pointer shadow-sm active:scale-95"
          >
            <RefreshCw className="w-4 h-4" />
            <span>รีเฟรชหน้าเว็บ</span>
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
