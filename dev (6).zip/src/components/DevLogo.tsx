import React, { useState } from 'react';
import { useTheme } from '../lib/theme';

interface DevLogoProps {
  className?: string;
  height?: number | string;
  width?: number | string;
  variant?: 'svg' | 'image';
  withText?: boolean;
  forcedTheme?: 'dark' | 'light';
}

export const ASTRAX_LOGO_DARK_URL = "https://i.postimg.cc/yNjYRK4f/astrax-logo-white-transparent.png";
export const ASTRAX_LOGO_LIGHT_URL = "https://i.postimg.cc/vZQmZTCb/astrax-logo-black-transparent.png";
export const ASTRAX_LOGO_URL = ASTRAX_LOGO_DARK_URL;
export const ZENONE_LOGO_URL = ASTRAX_LOGO_DARK_URL;

export const DevLogo: React.FC<DevLogoProps> = ({
  className = "h-12 w-auto",
  height,
  width,
  withText = false,
  forcedTheme,
}) => {
  const { theme } = useTheme();
  const [imgError, setImgError] = useState(false);

  // If forcedTheme is provided, render only that theme's logo
  if (forcedTheme) {
    const src = forcedTheme === 'light' ? ASTRAX_LOGO_LIGHT_URL : ASTRAX_LOGO_DARK_URL;
    return (
      <div className={`flex items-center gap-2.5 select-none ${className}`}>
        {!imgError ? (
          <img
            src={src}
            alt="Astrax Logo"
            className="h-full w-auto object-contain drop-shadow-md transition-transform duration-200 group-hover:scale-105"
            style={{ height, width }}
            onError={() => setImgError(true)}
          />
        ) : (
          <div className="h-9 px-4 rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 flex items-center justify-center font-black text-white text-base shadow-lg tracking-wider border border-blue-500/30">
            ASTRAX
          </div>
        )}
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {!imgError ? (
        <>
          {/* Dark Mode Logo (White Transparent) */}
          <img
            src={ASTRAX_LOGO_DARK_URL}
            alt="Astrax Logo (Dark Mode)"
            className="astrax-logo-dark h-full w-auto object-contain drop-shadow-md transition-transform duration-200 group-hover:scale-105"
            style={{ height, width }}
            onError={() => setImgError(true)}
          />
          {/* Light Mode Logo (Black Transparent) */}
          <img
            src={ASTRAX_LOGO_LIGHT_URL}
            alt="Astrax Logo (Light Mode)"
            className="astrax-logo-light h-full w-auto object-contain drop-shadow-md transition-transform duration-200 group-hover:scale-105"
            style={{ height, width }}
            onError={() => setImgError(true)}
          />
        </>
      ) : (
        <div className="h-9 px-4 rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 flex items-center justify-center font-black text-white text-base shadow-lg tracking-wider border border-blue-500/30">
          ASTRAX
        </div>
      )}
      {withText && (
        <span className="font-black text-xl tracking-tight text-white font-sans">
          ASTRAX<span className="text-blue-500">.</span>
        </span>
      )}
    </div>
  );
};

export const AstraxLogo = DevLogo;
export const ZenoneLogo = DevLogo;
export default DevLogo;
