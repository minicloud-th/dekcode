import React, { useState, useRef } from 'react';
import { 
  Landmark, 
  Copy, 
  Check, 
  UploadCloud, 
  Trash2, 
  RefreshCw,
  Image as ImageIcon,
  ArrowRight,
  Zap,
  CheckCircle2
} from 'lucide-react';
import Swal from 'sweetalert2';
import axios from 'axios';
import { toast } from '../lib/toastStore';
import { UserPlan } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { AnimatedScroll } from './AnimatedScroll';

interface WalletViewProps {
  userPlan: UserPlan | null;
  setUserPlan: React.Dispatch<React.SetStateAction<UserPlan | null>>;
  onTopupSuccess?: (entry: any) => void;
  userId?: string | null;
  siteSettings?: any;
  topupHistory?: any[];
  setActiveView?: (view: any) => void;
}

export const WalletView: React.FC<WalletViewProps> = ({ 
  userPlan, 
  setUserPlan, 
  onTopupSuccess, 
  userId,
  siteSettings,
  setActiveView
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [copiedAcc, setCopiedAcc] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);
  const [customAmount, setCustomAmount] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Bank Account Information
  const bankAccountNo = siteSettings?.promptpay_number || "196-3-87032-5";
  const bankAccountRaw = bankAccountNo.replace(/[^0-9]/g, "");
  const bankAccountName = siteSettings?.promptpay_name || "นาย กรวิชญ์";
  const bankName = "ธนาคารกสิกรไทย (K-Bank)";

  // Copy Account Number
  const handleCopyAccount = () => {
    navigator.clipboard.writeText(bankAccountRaw);
    setCopiedAcc(true);
    setTimeout(() => setCopiedAcc(false), 2000);
    Swal.fire({
      toast: true,
      position: 'top-end',
      icon: 'success',
      title: 'คัดลอกเลขบัญชีแล้ว',
      showConfirmButton: false,
      timer: 1500,
      background: '#18181b',
      color: '#fff'
    });
  };

  // Handle File Input
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      toast.error('กรุณาเลือกไฟล์รูปภาพสลิปเท่านั้น (PNG, JPG, WEBP)', 'ไฟล์ไม่ถูกต้อง');
      return;
    }

    if (file.size > 15 * 1024 * 1024) {
      toast.warning('ขนาดไฟล์ต้องไม่เกิน 15MB', 'ไฟล์ใหญ่เกินไป');
      return;
    }

    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) processFile(file);
  };

  const handleClearFile = () => {
    setSelectedFile(null);
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Submit Slip for Verification
  const handleSubmitSlip = async () => {
    if (!selectedFile) {
      toast.warning('โปรดอัปโหลดรูปภาพสลิปโอนเงินก่อนกดยืนยัน', 'กรุณาแนบสลิป');
      return;
    }

    setIsUploading(true);

    const reader = new FileReader();
    reader.onload = async (event) => {
      const result = event.target?.result as string;

      try {
        const parsedCustom = customAmount ? parseFloat(customAmount) : null;
        const finalAmount = (parsedCustom && parsedCustom > 0) ? parsedCustom : selectedAmount;

        const endpoint = (finalAmount && finalAmount > 0)
          ? `/api/slip/${finalAmount}`
          : '/api/slip';

        const response = await axios.post(endpoint, {
          img: result, // Full Data URL e.g. "data:image/jpeg;base64,..."
          tos: true,
          privacy: true,
          eula: true,
          amount: (finalAmount && finalAmount > 0) ? finalAmount : undefined
        });

        if (response.data.success) {
          const slipData = response.data.data || {};
          const amount = Number(response.data.amount || slipData.amount || finalAmount || 0);
          const transRef = response.data.transRef || slipData.ref || 'T-' + Date.now();
          const senderName = slipData.sender_name || '';
          const receiverName = slipData.receiver_name || '';
          const senderBank = slipData.sender_bank || '';
          const receiverBank = slipData.receiver_bank || '';

          if (setUserPlan) {
            setUserPlan((prev: UserPlan | null) => prev ? ({
              ...prev,
              balance: (prev.balance || 0) + amount
            }) : {
              username: 'User',
              isPremium: false,
              premiumExpireDate: null,
              balance: amount
            });
          }

          const topup = response.data.topup;
          const historyEntry = {
            id: topup ? topup.id : 'tu-' + transRef,
            type: 'topup',
            method: 'โอนผ่านธนาคาร (สแกนสลิป)',
            amount: amount,
            username: topup?.userId || userPlan?.username || 'User',
            status: 'success',
            date: slipData.date || (topup ? topup.date : new Date().toISOString()),
            billNumber: 'T-' + transRef.slice(-8).toUpperCase(),
            money: amount,
            title: `เติมเงินสำเร็จ ฿${amount.toLocaleString()}`,
            image: previewUrl || 'https://images.unsplash.com/photo-1613243555988-441166d4d6fd?auto=format&fit=crop&w=800&q=80'
          };

          if (onTopupSuccess) {
            onTopupSuccess(historyEntry);
          }

          setIsUploading(false);
          handleClearFile();
          setSelectedAmount(null);
          setCustomAmount('');

          Swal.fire({
            title: 'เติมเงินสำเร็จ!',
            html: `
              <div style="text-align: left; font-size: 13px; color: #cbd5e1; background: #09090b; padding: 16px; border-radius: 12px; border: 1px solid #27272a; margin-top: 10px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                  <span style="color: #94a3b8;">ยอดเงินเข้า:</span>
                  <span style="color: #10b981; font-weight: bold; font-size: 16px;">+฿${amount.toLocaleString()} บาท</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                  <span style="color: #94a3b8;">เลขอ้างอิง:</span>
                  <span style="font-family: monospace; color: #60a5fa;">${transRef}</span>
                </div>
                ${senderName ? `
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                  <span style="color: #94a3b8;">ผู้โอน:</span>
                  <span style="color: #fff;">${senderName} ${senderBank ? `(${senderBank})` : ''}</span>
                </div>` : ''}
                ${receiverName ? `
                <div style="display: flex; justify-content: space-between;">
                  <span style="color: #94a3b8;">ผู้รับ:</span>
                  <span style="color: #fff;">${receiverName} ${receiverBank ? `(${receiverBank})` : ''}</span>
                </div>` : ''}
              </div>
            `,
            icon: 'success',
            background: '#18181b',
            color: '#fff',
            confirmButtonColor: '#2563eb'
          });
        } else {
          setIsUploading(false);
          const slug = response.data.slug;
          Swal.fire({
            title: 'ตรวจสอบสลิปไม่สำเร็จ',
            text: response.data.error || 'ไม่พบ QR Code หรือสลิปนี้ถูกใช้งานไปแล้ว',
            footer: slug ? `<span style="font-family: monospace; font-size: 11px; color: #94a3b8;">Code: ${slug}</span>` : undefined,
            icon: 'error',
            background: '#18181b',
            color: '#fff',
            confirmButtonColor: '#2563eb'
          });
        }
      } catch (err: any) {
        setIsUploading(false);
        const errMsg = err.response?.data?.error || err.message || 'ระบบขัดข้อง โปรดลองใหม่อีกครั้ง';
        const slug = err.response?.data?.slug;
        Swal.fire({
          title: 'ตรวจสอบสลิปไม่สำเร็จ',
          text: errMsg,
          footer: slug ? `<span style="font-family: monospace; font-size: 11px; color: #94a3b8;">Code: ${slug}</span>` : undefined,
          icon: 'error',
          background: '#18181b',
          color: '#fff',
          confirmButtonColor: '#2563eb'
        });
      }
    };
    reader.readAsDataURL(selectedFile);
  };

  return (
    <AnimatedScroll direction="up" hideOnScroll={true}>
      <div className="w-full max-w-xl mx-auto px-4 py-8 font-sans text-label min-h-[80vh] flex flex-col justify-center">
        
        {/* Main Apple Clean Card */}
        <div className="bg-surface border border-separator rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          
          {/* Header & Balance */}
          <div className="flex items-center justify-between border-b border-separator pb-5">
            <div>
              <h1 className="text-xl sm:text-2xl font-semibold text-label tracking-tight">
                เติมเงินเข้าบัญชี
              </h1>
              <p className="text-xs text-label-2 mt-0.5">
                โอนเงินผ่าน PromptPay และแนบสลิปเพื่อปรับยอดอัตโนมัติ
              </p>
            </div>
            
            <div className="text-right">
              <span className="text-xs text-label-3 block font-medium">ยอดเงินคงเหลือ</span>
              <span className="text-lg font-semibold font-sans tabular-nums text-label tracking-tight">
                ฿{(userPlan?.balance || 0).toLocaleString()}
              </span>
            </div>
          </div>

          {/* QR Code & Bank Info */}
          <div className="flex flex-col sm:flex-row items-center gap-5 bg-surface-2 border border-separator rounded-2xl p-5 sm:p-6 shadow-sm">
            {/* QR Code */}
            <div className="p-3 bg-white rounded-2xl shadow-sm shrink-0">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=00020101021129370016A00000067701011101130066${bankAccountRaw}5802TH53037646304`}
                alt="PromptPay QR"
                className="w-32 h-32 object-contain rounded-xl"
              />
            </div>

            {/* Account Details */}
            <div className="flex-1 w-full text-center sm:text-left space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-success/15 text-success text-xs font-medium">
                <Landmark className="w-3.5 h-3.5" />
                <span>{bankName}</span>
              </div>

              <div>
                <span className="text-xs text-label-2 block">เลขบัญชี / พร้อมเพย์</span>
                <div className="flex items-center justify-center sm:justify-between gap-2 mt-0.5">
                  <span className="text-lg font-sans tabular-nums font-semibold text-label tracking-normal">
                    {bankAccountNo}
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyAccount}
                    className="p-2 rounded-full bg-surface hover:bg-surface-2 text-label-2 hover:text-label transition-all cursor-pointer active:scale-90 shrink-0 border border-separator"
                    title="คัดลอกเลขบัญชี"
                  >
                    {copiedAcc ? <Check className="w-4 h-4 text-success" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="pt-1 text-xs text-label-2">
                <span>ชื่อบัญชี: </span>
                <span className="text-label font-medium">{bankAccountName}</span>
              </div>
            </div>
          </div>

          {/* Quick Amount Selector */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-medium text-label-2 flex items-center gap-1.5">
                <span>ยอดเงินที่โอน</span>
                <span className="text-xs text-label-3 font-normal">
                  (ระบุเพื่อตรวจจับได้เร็วยิ่งขึ้น)
                </span>
              </label>
              {(selectedAmount !== null || customAmount) && (
                <button
                  type="button"
                  onClick={() => { setSelectedAmount(null); setCustomAmount(''); }}
                  className="text-xs text-link hover:underline cursor-pointer"
                >
                  ตรวจจับอัตโนมัติ
                </button>
              )}
            </div>

            <div className="grid grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => { setSelectedAmount(null); setCustomAmount(''); }}
                className={`py-2 px-2.5 rounded-full text-xs font-medium border transition-all cursor-pointer flex items-center justify-center gap-1 active:scale-95 ${
                  selectedAmount === null && !customAmount
                    ? 'bg-accent/15 border-accent text-link'
                    : 'bg-surface-2 border-separator text-label-2 hover:text-label hover:bg-surface'
                }`}
              >
                <Zap className="w-3 h-3 text-link" />
                <span>อัตโนมัติ</span>
              </button>
              {[50, 100, 200, 300, 500, 1000].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => { setSelectedAmount(amt); setCustomAmount(''); }}
                  className={`py-2 px-2.5 rounded-full text-xs font-medium border transition-all cursor-pointer active:scale-95 ${
                    selectedAmount === amt && !customAmount
                      ? 'bg-accent border-accent text-white shadow-sm'
                      : 'bg-surface-2 border-separator text-label-2 hover:text-label hover:bg-surface'
                  }`}
                >
                  ฿{amt}
                </button>
              ))}
              <div className="col-span-1">
                <input
                  type="number"
                  placeholder="อื่นๆ..."
                  value={customAmount}
                  onChange={(e) => {
                    setCustomAmount(e.target.value);
                    setSelectedAmount(null);
                  }}
                  className="w-full h-full min-h-[34px] bg-surface-2 border border-separator focus:border-accent rounded-full px-3 text-xs text-label placeholder:text-label-3 outline-none"
                />
              </div>
            </div>
          </div>

          {/* Slip Upload Area */}
          <div>
            <label className="text-xs font-medium text-label-2 block mb-2">
              แนบรูปสลิปหลักฐานการโอน
            </label>

            {!previewUrl ? (
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border border-dashed rounded-2xl p-7 text-center cursor-pointer transition-all duration-200 flex flex-col items-center justify-center ${
                  isDragOver 
                    ? 'border-accent bg-accent/10' 
                    : 'border-separator hover:border-separator/80 bg-surface-2 hover:bg-surface'
                }`}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="image/png, image/jpeg, image/jpg, image/webp"
                  className="hidden"
                />
                
                <UploadCloud className="w-8 h-8 text-label-3 mb-2" />
                <p className="text-xs font-medium text-label">
                  คลิกเพื่อเลือกสลิป หรือ ลากรูปภาพมาวางที่นี่
                </p>
                <p className="text-xs text-label-3 mt-1">
                  รองรับ PNG, JPG, WEBP (มี QR Code ชัดเจน)
                </p>
              </div>
            ) : (
              /* Selected File Preview */
              <div className="bg-surface-2 border border-separator rounded-2xl p-3.5 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-14 bg-surface rounded-xl overflow-hidden shrink-0 border border-separator">
                    <img src={previewUrl} alt="Slip" className="w-full h-full object-cover" />
                  </div>
                  <div className="min-w-0 text-left">
                    <p className="text-xs font-semibold text-label truncate max-w-[180px] sm:max-w-xs">
                      {selectedFile?.name || "slip.jpg"}
                    </p>
                    <p className="text-xs text-label-3 mt-0.5">
                      {selectedFile ? (selectedFile.size / 1024).toFixed(1) + ' KB' : 'พร้อมตรวจสอบ'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="p-2.5 rounded-full bg-surface hover:bg-surface-2 text-label-2 hover:text-label transition-all cursor-pointer border border-separator"
                    title="เปลี่ยนรูปภาพ"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={handleClearFile}
                    className="p-2.5 rounded-full bg-danger/10 hover:bg-danger/20 text-danger transition-all cursor-pointer"
                    title="ลบ"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Submit Button */}
          <button
            type="button"
            onClick={handleSubmitSlip}
            disabled={isUploading || !selectedFile}
            className="w-full py-3 px-5 rounded-full bg-accent hover:bg-accent-hover disabled:bg-surface-2 disabled:text-label-3 text-white font-medium text-sm transition-all flex items-center justify-center gap-2 cursor-pointer disabled:cursor-not-allowed shadow-sm active:scale-98"
          >
            {isUploading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>กำลังตรวจสอบสลิป...</span>
              </>
            ) : (
              <>
                <span>ยืนยันและสแกนสลิป</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>

        </div>

      </div>
    </AnimatedScroll>
  );
};

export default WalletView;
