import React from "react";
import { ArrowRight } from "lucide-react";
import { Product } from "../types";
import { ImageWithFallback } from "./ui/ImageWithFallback";

interface ProductCardProps {
  product: Product;
  onClick: (id: string) => void;
  className?: string;
  categoryName?: string;
  showCategory?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onClick,
  className = "",
  categoryName,
  showCategory = true,
}) => {
  const isAvailable = (product.stock ?? 0) > 0;
  const stockCount = product.stock ?? 0;
  const hasDiscount = Boolean(
    product.originalPrice && product.price < product.originalPrice
  );
  const discountPercent =
    hasDiscount && product.originalPrice
      ? Math.round(
          ((product.originalPrice - product.price) / product.originalPrice) *
            100
        )
      : null;

  // Clean unboxed category label
  const displayCategory =
    categoryName ||
    (typeof product.category === "string"
      ? product.category === "premium_apps"
        ? "Streaming & Apps"
        : product.category === "software_tools"
        ? "Software & Key"
        : product.category === "game_accounts"
        ? "Game Account"
        : product.category === "steam_wallet"
        ? "Gift Card"
        : product.category
      : "สินค้าดิจิทัล");

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    onClick(product.id);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLAnchorElement>) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      onClick(product.id);
    }
  };

  return (
    <a
      href={`/products/${product.id}`}
      onClick={handleClick}
      onKeyDown={handleKeyDown}
      role="link"
      tabIndex={0}
      aria-label={`${product.name} ราคา ฿${(product.price || 0).toLocaleString()} ${isAvailable ? `พร้อมส่ง ${stockCount} ชิ้น` : 'สินค้าหมด'}`}
      className={`group relative bg-surface hover:bg-surface-2 border border-separator rounded-3xl p-4 sm:p-5 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 hover:shadow-xl cursor-pointer select-none no-underline focus-visible:ring-2 focus-visible:ring-accent ${className}`}
    >
      {/* Product Image Stage */}
      <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-bg shrink-0 border border-separator/60 p-3 flex items-center justify-center">
        <ImageWithFallback
          src={product.imageUrl}
          alt={product.name}
          width={300}
          height={300}
          loading="lazy"
          className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300"
        />

        {/* Quiet Discount or Hot Pill */}
        {discountPercent ? (
          <div className="absolute top-3 left-3 pointer-events-none z-10">
            <span className="px-2.5 py-0.5 rounded-full bg-danger/15 border border-danger/25 text-danger text-xs font-semibold backdrop-blur-md">
              ลด {discountPercent}%
            </span>
          </div>
        ) : product.isPopular ? (
          <div className="absolute top-3 left-3 pointer-events-none z-10">
            <span className="px-2.5 py-0.5 rounded-full bg-accent/15 border border-accent/25 text-link text-xs font-semibold backdrop-blur-md">
              ยอดนิยม
            </span>
          </div>
        ) : null}

        {/* Out of Stock Overlay */}
        {!isAvailable && (
          <div className="absolute inset-0 bg-bg/80 backdrop-blur-sm flex items-center justify-center z-20">
            <span className="px-3 py-1 rounded-full bg-surface-2 border border-separator text-label-2 font-medium text-xs">
              สินค้าหมด
            </span>
          </div>
        )}
      </div>

      {/* Product Content Details */}
      <div className="mt-4 flex flex-col flex-1 justify-between gap-3 min-w-0">
        <div className="min-w-0">
          {/* Subtle Category Kicker */}
          {showCategory && (
            <p className="text-xs text-label-2 font-medium mb-1 truncate">
              {displayCategory}
            </p>
          )}

          {/* Product Title */}
          <h3
            title={product.name}
            className="text-sm sm:text-base font-semibold text-label tracking-tight line-clamp-1 leading-snug group-hover:text-link transition-colors"
          >
            {product.name}
          </h3>

          {/* Stock Indicator */}
          <div className="mt-1 flex items-center gap-1.5 text-xs sm:text-sm">
            {isAvailable ? (
              <span className="flex items-center gap-1.5 text-label-2">
                <span className="w-2 h-2 rounded-full bg-success shrink-0" />
                <span>พร้อมส่ง ({stockCount})</span>
              </span>
            ) : (
              <span className="flex items-center gap-1.5 text-label-3">
                <span className="w-2 h-2 rounded-full bg-label-3 shrink-0" />
                <span>หมดชั่วคราว</span>
              </span>
            )}
          </div>
        </div>

        {/* Bottom Row: Price & Apple Order Pill */}
        <div className="pt-3 flex items-center justify-between border-t border-separator">
          {/* Price */}
          <div className="flex flex-col">
            <div className="flex items-baseline gap-1">
              <span className="text-base sm:text-lg font-semibold text-label tracking-tight font-sans tabular-nums">
                ฿{(product.price || 0).toLocaleString()}
              </span>
            </div>
            {hasDiscount && product.originalPrice && (
              <span className="text-xs text-label-3 line-through tabular-nums">
                ฿{product.originalPrice.toLocaleString()}
              </span>
            )}
          </div>

          {/* Apple-style Buy Pill Button */}
          <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-surface-2 group-hover:bg-accent text-label-2 group-hover:text-white flex items-center justify-center transition-all duration-200 shrink-0" aria-hidden="true">
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </div>
        </div>
      </div>
    </a>
  );
};

export default ProductCard;
