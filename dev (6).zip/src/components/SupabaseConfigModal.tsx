import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Database,
  X,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  AlertCircle,
  RefreshCw,
  Code2,
  CheckCircle2,
  Trash2,
} from "lucide-react";
import Swal from "sweetalert2";
import {
  getStoredSupabaseConfig,
  setSupabaseCredentials,
  clearSupabaseCredentials,
  testSupabaseConnection,
} from "../lib/supabase";
import { SUPABASE_SQL_SCHEMA } from "../lib/supabaseSchema";

interface SupabaseConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export const SupabaseConfigModal: React.FC<SupabaseConfigModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [activeTab, setActiveTab] = useState<"credentials" | "sql">("credentials");
  const [url, setUrl] = useState("");
  const [key, setKey] = useState("");
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{
    success: boolean;
    message: string;
  } | null>(null);
  const [copiedSql, setCopiedSql] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const cfg = getStoredSupabaseConfig();
      setUrl(cfg.url || "");
      setKey(cfg.key || "");
      setTestResult(null);
    }
  }, [isOpen]);

  const handleTest = async () => {
    if (!url.trim() || !key.trim()) {
      Swal.fire({
        icon: "warning",
        title: "ข้อมูลไม่ครบถ้วน",
        text: "กรุณาระบุทั้ง Supabase Project URL และ Anon Key",
      });
      return;
    }

    setTesting(true);
    setTestResult(null);
    try {
      const res = await testSupabaseConnection(url.trim(), key.trim());
      setTestResult(res);
      if (res.success) {
        Swal.fire({
          icon: "success",
          title: "เชื่อมต่อได้สำเร็จ",
          text: res.message,
          timer: 2000,
          showConfirmButton: false,
        });
      } else {
        Swal.fire({
          icon: "error",
          title: "การเชื่อมต่อล้มเหลว",
          text: res.message,
        });
      }
    } finally {
      setTesting(false);
    }
  };

  const handleSave = () => {
    if (!url.trim() || !key.trim()) {
      Swal.fire({
        icon: "warning",
        title: "ข้อมูลไม่ครบถ้วน",
        text: "กรุณาระบุทั้ง Supabase Project URL และ Anon Key",
      });
      return;
    }

    setSupabaseCredentials(url.trim(), key.trim());

    Swal.fire({
      icon: "success",
      title: "บันทึกและเชื่อมต่อ Supabase เรียบร้อย",
      text: "ระบบจะเริ่มดึงและซิงค์ข้อมูลจริงกับ Supabase ทันที",
      timer: 1600,
      showConfirmButton: false,
    });

    if (onSuccess) onSuccess();
    onClose();
  };

  const handleClear = () => {
    clearSupabaseCredentials();
    setUrl("");
    setKey("");
    setTestResult(null);
    Swal.fire({
      icon: "info",
      title: "ยกเลิกการเชื่อมต่อแล้ว",
      text: "ระบบจะใช้ Local Storage ชั่วคราว",
      timer: 1400,
      showConfirmButton: false,
      background: "#141414",
      color: "#fff",
    });
    if (onSuccess) onSuccess();
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_SCHEMA);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2500);
    Swal.fire({
      icon: "success",
      title: "คัดลอกคำสั่ง SQL แล้ว",
      text: "นำไปวางในเมนู SQL Editor ใน Supabase Dashboard แล้วกด Run ได้เลยครับ",
      timer: 2000,
      showConfirmButton: false,
    });
  };

  if (!isOpen) return null;

  const currentCfg = getStoredSupabaseConfig();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-xl animate-in fade-in duration-200">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.96 }}
        className="w-full max-w-2xl bg-surface border border-separator rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] text-label"
      >
        {/* Modal Header */}
        <div className="px-6 py-4.5 border-b border-separator flex items-center justify-between bg-surface">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-accent/15 border border-accent/25 text-accent flex items-center justify-center shrink-0">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-label flex items-center gap-2">
                <span>เชื่อมต่อ Supabase Database</span>
                {currentCfg.isConfigured ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-success/15 text-success border border-success/30">
                    <CheckCircle2 className="w-3 h-3" /> เชื่อมต่อแล้ว
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-warning/15 text-warning border border-warning/30">
                    <AlertCircle className="w-3 h-3" /> ยังไม่เชื่อมต่อ
                  </span>
                )}
              </h2>
              <p className="text-xs text-label-2 mt-0.5">
                ฐานข้อมูลจริงสำหรับจัดการสินค้า หมวดหมู่ คำสั่งซื้อ และยอดเงิน
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-label-3 hover:text-label hover:bg-surface-2 transition-colors cursor-pointer"
            aria-label="ปิด"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-separator bg-surface-2/50 px-5 pt-2">
          <button
            onClick={() => setActiveTab("credentials")}
            className={`pb-2.5 px-3 text-xs sm:text-sm font-medium border-b-2 transition-all cursor-pointer ${
              activeTab === "credentials"
                ? "border-accent text-label"
                : "border-transparent text-label-2 hover:text-label"
            }`}
          >
            1. ตั้งค่า API Key & URL
          </button>
          <button
            onClick={() => setActiveTab("sql")}
            className={`pb-2.5 px-3 text-xs sm:text-sm font-medium border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === "sql"
                ? "border-accent text-label"
                : "border-transparent text-label-2 hover:text-label"
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>2. คำสั่ง SQL สร้างตาราง</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1 font-sans">
          {activeTab === "credentials" ? (
            <div className="space-y-4">
              {/* Instructions banner */}
              <div className="p-4 rounded-2xl bg-accent/10 border border-accent/20 text-xs text-label-2 leading-relaxed space-y-1">
                <div className="font-semibold text-accent flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4" />
                  <span>วิธีดู Supabase Project URL และ Anon Key ของคุณ:</span>
                </div>
                <p>
                  1. ไปที่{" "}
                  <a
                    href="https://supabase.com/dashboard"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-link underline hover:text-accent-hover inline-flex items-center gap-0.5"
                  >
                    Supabase Dashboard <ExternalLink className="w-3 h-3 inline" />
                  </a>
                </p>
                <p>2. เข้าโปรเจกต์ของคุณ &gt; เลือก <b>Project Settings (รูปเฟือง)</b> &gt; เมนู <b>API</b></p>
                <p>3. คัดลอก <b>Project URL</b> และ <b>anon / public key</b> มาวางในช่องด้านล่างนี้</p>
              </div>

              {/* URL Input */}
              <div>
                <label className="block text-xs font-semibold text-label mb-1.5">
                  Project URL
                </label>
                <input
                  type="text"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://xyzabcdefghijklmnop.supabase.co"
                  className="w-full px-4 py-2.5 rounded-full bg-surface-2 border border-separator focus:border-accent text-xs sm:text-sm text-label placeholder-label-3 outline-none font-mono"
                />
              </div>

              {/* Anon Key Input */}
              <div>
                <label className="block text-xs font-semibold text-label mb-1.5">
                  Anon / Public Key (API Key)
                </label>
                <textarea
                  rows={3}
                  value={key}
                  onChange={(e) => setKey(e.target.value)}
                  placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                  className="w-full px-4 py-3 rounded-2xl bg-surface-2 border border-separator focus:border-accent text-xs sm:text-sm text-label placeholder-label-3 outline-none font-mono resize-none"
                />
              </div>

              {/* Test Status feedback */}
              {testResult && (
                <div
                  className={`p-3.5 rounded-2xl border text-xs flex items-start gap-2 ${
                    testResult.success
                      ? "bg-success/10 border-success/25 text-success"
                      : "bg-danger/10 border-danger/25 text-danger"
                  }`}
                >
                  {testResult.success ? (
                    <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-success" />
                  ) : (
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-danger" />
                  )}
                  <span>{testResult.message}</span>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-surface-2 border border-separator text-xs text-label-2 space-y-1.5">
                <div className="font-semibold text-label flex items-center justify-between">
                  <span>ขั้นตอนการรันตารางใน Supabase:</span>
                  <button
                    onClick={handleCopySql}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-accent hover:bg-accent-hover text-white font-medium text-xs transition-colors cursor-pointer shadow-sm"
                  >
                    {copiedSql ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-white" />
                        <span>คัดลอกเรียบร้อย!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>คัดลอก SQL ทั้งหมด</span>
                      </>
                    )}
                  </button>
                </div>
                <p>1. ไปที่ Supabase Dashboard &gt; เข้าเมนู <b>SQL Editor</b> ทางแถบเมนูด้านซ้าย</p>
                <p>2. กดปุ่ม <b>+ New query</b></p>
                <p>3. วางโค้ด SQL ด้านล่างนี้ทั้งหมด &gt; กดปุ่ม <b>Run</b> (หรือกด Ctrl+Enter)</p>
                <p className="text-link">
                  ตารางทั้งหมด 7 ตารางพร้อมสิทธิ์การเข้าถึง (RLS) จะถูกสร้างขึ้นมาพร้อมใช้งานทันที
                </p>
              </div>

              {/* Code viewer */}
              <div className="relative rounded-2xl border border-separator bg-surface-2 overflow-hidden">
                <div className="flex items-center justify-between px-3.5 py-2 bg-surface border-b border-separator text-xs text-label-3">
                  <span className="font-mono">schema.sql (ตาราง: profiles, categories, products, orders, topups, license_keys, site_settings)</span>
                  <button
                    onClick={handleCopySql}
                    className="hover:text-label transition-colors cursor-pointer flex items-center gap-1 font-medium text-xs text-link"
                  >
                    <Copy className="w-3 h-3" />
                    <span>คัดลอก</span>
                  </button>
                </div>
                <pre className="p-3.5 text-xs font-mono text-label overflow-x-auto max-h-[280px] leading-relaxed selection:bg-accent/30 selection:text-white">
                  {SUPABASE_SQL_SCHEMA}
                </pre>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3.5 border-t border-separator bg-surface-2/40 flex items-center justify-between gap-3">
          <div>
            {currentCfg.isConfigured && activeTab === "credentials" && (
              <button
                type="button"
                onClick={handleClear}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium text-danger hover:bg-danger/10 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>ยกเลิกการเชื่อมต่อ</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2.5">
            {activeTab === "credentials" && (
              <button
                type="button"
                onClick={handleTest}
                disabled={testing}
                className="px-4 py-2 rounded-full bg-surface-2 hover:bg-surface border border-separator text-xs sm:text-sm font-medium text-label transition-colors cursor-pointer flex items-center gap-2 disabled:opacity-50"
              >
                {testing ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>กำลังทดสอบ...</span>
                  </>
                ) : (
                  <span>ทดสอบการเชื่อมต่อ</span>
                )}
              </button>
            )}

            {activeTab === "credentials" ? (
              <button
                type="button"
                onClick={handleSave}
                className="px-5 py-2 rounded-full bg-accent hover:bg-accent-hover text-white text-xs sm:text-sm font-medium transition-all shadow-sm cursor-pointer active:scale-95"
              >
                บันทึกและเชื่อมต่อ
              </button>
            ) : (
              <button
                type="button"
                onClick={handleCopySql}
                className="px-5 py-2 rounded-full bg-accent hover:bg-accent-hover text-white text-xs sm:text-sm font-medium transition-all shadow-sm cursor-pointer active:scale-95 flex items-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>คัดลอกคำสั่ง SQL ทั้งหมด</span>
              </button>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default SupabaseConfigModal;
