# Astrax Store & Community

Astrax digital gaming store and account management platform.

## Tech Stack
- Frontend: React 19, TypeScript, Vite, Tailwind CSS v4, Lucide Icons, Framer Motion
- Backend / Server: Node.js, Express, TSX
- Database & Auth: Supabase / Firebase / Cloud DB

## Getting Started

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment
Copy `.env.example` to `.env` and provide your credentials:
```bash
cp .env.example .env
```

Key environment variables:
- `VITE_SUPABASE_URL`: Supabase project URL
- `VITE_SUPABASE_ANON_KEY`: Supabase client anonymous key
- `SUPABASE_SERVICE_ROLE_KEY`: Server-side Supabase service key
- `VITE_USE_MOCK_API`: Set to `false` for live backend
- `SLIP_VERIFY_API_URL` & `SLIP_VERIFY_API_KEY`: Bank slip verification configuration
- `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY`: Firebase credentials

### 3. Run Development Server
```bash
npm run dev
```

### 4. Build for Production
```bash
npm run build
```
