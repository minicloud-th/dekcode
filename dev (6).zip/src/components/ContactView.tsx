import React from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, MessageSquare, Mail, Send, ExternalLink } from 'lucide-react';

interface ContactViewProps {
  onBack: () => void;
  facebookLink?: string;
  discordLink?: string;
  instagramLink?: string;
  contactEmail?: string;
}

export const ContactView: React.FC<ContactViewProps> = ({ 
  onBack, 
  facebookLink = '#',
  discordLink = 'https://discord.gg/2NSuSmkzun',
  instagramLink = '#',
  contactEmail,
}) => {
  return (
    <div className="w-full max-w-5xl mx-auto p-4 sm:p-6 lg:p-8 font-sans text-label min-h-[85vh]">
      {/* Back button */}
      <motion.button 
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        onClick={onBack}
        className="mb-6 flex items-center gap-2 text-label-2 hover:text-label transition-all font-medium bg-surface-2 hover:bg-surface px-4 py-2 border border-separator rounded-full text-xs sm:text-sm active:scale-95 cursor-pointer shadow-sm"
      >
        <ArrowLeft className="w-4 h-4 text-link" /> 
        <span>ย้อนกลับ</span>
      </motion.button>

      {/* Header Card */}
      <motion.div 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl border border-separator bg-surface p-6 sm:p-7 mb-6 shadow-2xl"
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-surface-2 border border-separator flex items-center justify-center text-link shrink-0 shadow-inner">
              <MessageSquare className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-semibold text-label tracking-tight">
                ศูนย์บริการและติดต่อเรา
              </h1>
              <p className="text-label-2 text-xs sm:text-sm font-normal mt-0.5">
                ติดต่อสอบถามทีมงานเพื่อขอความช่วยเหลือในการใช้งาน
              </p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Social Cards Grid */}
      <div className={`grid grid-cols-1 ${contactEmail ? 'md:grid-cols-3' : 'md:grid-cols-2'} gap-4 sm:gap-6`}>
        {/* Discord */}
        <motion.a 
          href={discordLink} 
          target={discordLink !== '#' ? "_blank" : "_self"} 
          rel="noopener noreferrer"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, delay: 0.05 }}
          whileHover={{ y: -2 }}
          className="bg-surface border border-separator hover:border-[#5865F2]/50 transition-all p-6 sm:p-8 flex flex-col items-center justify-center text-center group cursor-pointer relative overflow-hidden rounded-3xl shadow-xl"
          onClick={(e) => {
            if (discordLink === '#') e.preventDefault();
          }}
        >
          <div className="w-16 h-16 bg-[#5865F2]/10 border border-[#5865F2]/20 flex items-center justify-center mb-5 group-hover:scale-105 transition-transform rounded-2xl shadow-sm">
            <svg width="32" height="32" viewBox="0 0 127.14 96.36" fill="#5865F2" xmlns="http://www.w3.org/2000/svg">
              <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.68,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,46,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.31,60,73.31,53s5-12.74,11.43-12.74S96.1,46,96,53,91,65.69,84.69,65.69Z"/>
            </svg>
          </div>
          <h2 className="text-lg font-semibold text-label mb-1.5 group-hover:text-[#5865F2] transition-colors">
            Discord Community
          </h2>
          <p className="text-label-2 text-xs sm:text-sm font-normal mb-5">
            พูดคุย สอบถามปัญหา แจ้งเคลมสินค้า และรับข่าวสารโปรโมชั่นล่าสุดผ่าน Discord
          </p>
          <div className="px-6 py-2.5 bg-[#5865F2] hover:bg-[#4752C4] text-white font-medium text-xs rounded-full shadow-sm transition-all flex items-center gap-2 active:scale-95">
            <span>เข้าร่วมเซิร์ฟเวอร์ Discord</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </div>
        </motion.a>

        {/* Facebook */}
        <motion.a 
          href={facebookLink} 
          target={facebookLink !== '#' ? "_blank" : "_self"} 
          rel="noopener noreferrer"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, delay: 0.1 }}
          whileHover={{ y: -2 }}
          className="bg-surface border border-separator hover:border-[#1877F2]/50 transition-all p-6 sm:p-8 flex flex-col items-center justify-center text-center group cursor-pointer relative overflow-hidden rounded-3xl shadow-xl"
          onClick={(e) => {
            if (facebookLink === '#') e.preventDefault();
          }}
        >
          <div className="w-16 h-16 bg-[#1877F2]/10 border border-[#1877F2]/20 flex items-center justify-center mb-5 group-hover:scale-105 transition-transform rounded-2xl shadow-sm">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="#1877F2" xmlns="http://www.w3.org/2000/svg">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.469h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.469h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
            </svg>
          </div>
          <h2 className="text-lg font-semibold text-label mb-1.5 group-hover:text-[#1877F2] transition-colors">
            Facebook Page
          </h2>
          <p className="text-label-2 text-xs sm:text-sm font-normal mb-5">
            ส่งข้อความผ่านทาง Facebook Inbox เพื่อขอความช่วยเหลือโดยตรงจากแอดมิน
          </p>
          <div className="px-6 py-2.5 bg-[#1877F2] hover:bg-[#166fe5] text-white font-medium text-xs rounded-full shadow-sm transition-all flex items-center gap-2 active:scale-95">
            <span>ส่งข้อความ Facebook</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </div>
        </motion.a>

        {/* Email - Shown only if contactEmail is present */}
        {contactEmail && (
          <motion.a 
            href={`mailto:${contactEmail}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: 0.15 }}
            whileHover={{ y: -2 }}
            className="bg-surface border border-separator hover:border-link/50 transition-all p-6 sm:p-8 flex flex-col items-center justify-center text-center group cursor-pointer relative overflow-hidden rounded-3xl shadow-xl"
          >
            <div className="w-16 h-16 bg-surface-2 border border-separator flex items-center justify-center mb-5 group-hover:scale-105 transition-transform rounded-2xl shadow-sm text-link">
              <Mail className="w-8 h-8" />
            </div>
            <h2 className="text-lg font-semibold text-label mb-1.5 group-hover:text-link transition-colors">
              Email Support
            </h2>
            <p className="text-label-2 text-xs sm:text-sm font-normal mb-5">
              {contactEmail}
            </p>
            <div className="px-6 py-2.5 bg-surface-2 hover:bg-surface text-label border border-separator font-medium text-xs rounded-full shadow-sm transition-all flex items-center gap-2 active:scale-95">
              <span>ส่งอีเมลติดต่อ</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </div>
          </motion.a>
        )}
      </div>
    </div>
  );
};
