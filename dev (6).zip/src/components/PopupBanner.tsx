import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Check, ShoppingBag, Wallet, ShieldCheck, Zap, ArrowRight } from 'lucide-react';

interface PopupBannerProps {
  enabled?: boolean;
  imgUrl?: string;
  linkUrl?: string;
  title?: string;
  description?: string;
  siteName?: string;
  onNavigate?: (view: string) => void;
}

export const PopupBanner: React.FC<PopupBannerProps> = ({
  enabled = true,
  imgUrl,
  linkUrl,
  title,
  description,
  siteName = "Astrax",
  onNavigate,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [dontShow, setDontShow] = useState(false);

  useEffect(() => {
    if (!enabled) {
      setIsOpen(false);
      return;
    }

    const hideUntil = localStorage.getItem('hidePopupUntil');
    if (!hideUntil || Date.now() > parseInt(hideUntil, 10)) {
      // Smooth delayed appearance on initial load
      const showTimer = setTimeout(() => setIsOpen(true), 800);
      return () => clearTimeout(showTimer);
    }
  }, [enabled]);

  const handleClose = () => {
    if (dontShow) {
      const twentyFourHours = 24 * 60 * 60 * 1000;
      localStorage.setItem('hidePopupUntil', (Date.now() + twentyFourHours).toString());
    }
    setIsOpen(false);
  };

  const handleAction = (viewTarget?: string) => {
    handleClose();
    if (linkUrl) {
      window.open(linkUrl, '_blank', 'noopener,noreferrer');
    } else if (viewTarget && onNavigate) {
      onNavigate(viewTarget);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const defaultBanner = "https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=1200&auto=format&fit=crop";
  const bannerSource = imgUrl?.trim() || defaultBanner;

  return (
    <AnimatePresence>
      {isOpen && (
        <div 
          className="fixed inset-0 z-[120] flex items-center justify-center p-4 sm:p-6 bg-black/70 backdrop-blur-xl transition-opacity"
          onClick={handleClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 12 }}
            transition={{ type: "spring", damping: 28, stiffness: 300 }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-[460px] max-h-[90vh] bg-surface border border-separator overflow-hidden flex flex-col rounded-3xl shadow-2xl select-none text-label"
          >
            {/* Top Close Button */}
            <button
              onClick={handleClose}
              className="absolute top-3.5 right-3.5 z-20 w-8 h-8 rounded-full bg-surface/80 hover:bg-surface-2 border border-separator flex items-center justify-center text-label-2 hover:text-label transition-all cursor-pointer active:scale-95 shadow-sm backdrop-blur-md"
              aria-label="ปิดป๊อปอัพ"
              title="ปิด"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Visual Banner Area */}
            <div 
              onClick={() => handleAction('home')}
              className={`relative aspect-[16/8] sm:aspect-[16/7.5] w-full overflow-hidden bg-surface-2 shrink-0 ${linkUrl ? 'cursor-pointer group' : ''}`}
            >
              <img
                loading="lazy"
                src={bannerSource}
                alt="Announcement Banner"
                className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                onError={(e) => {
                  e.currentTarget.src = defaultBanner;
                }}
              />
              
              {/* Subtle Gradient Shadow */}
              <div className="absolute inset-0 bg-gradient-to-t from-surface via-transparent to-black/30" />

              {/* Tag / Badge */}
              <div className="absolute top-3.5 left-3.5 z-10 flex items-center gap-1.5 px-3 py-1 rounded-full bg-surface/90 text-label text-xs font-medium border border-separator shadow-sm backdrop-blur-md">
                <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                <span>ข่าวสารและโปรโมชั่น</span>
              </div>
            </div>

            {/* Content Area */}
            <div className="p-5 sm:p-6 flex flex-col space-y-4 overflow-y-auto">
              <div>
                <h3 className="text-lg sm:text-xl font-semibold text-label tracking-tight">
                  {title || `ยินดีต้อนรับสู่ ${siteName}`}
                </h3>
                <p className="text-xs sm:text-sm text-label-2 mt-1 leading-relaxed">
                  {description || "ศูนย์รวมไอดีเกมและดิจิทัล จัดส่งอัตโนมัติหลังชำระเงิน พร้อมระบบเติมเงินผ่านคิวอาร์โค้ดสะดวกและปลอดภัย"}
                </p>
              </div>

              {/* Feature Highlights Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 text-xs">
                <div className="p-3 rounded-2xl bg-surface-2 border border-separator flex items-center sm:flex-col sm:items-start gap-2">
                  <div className="w-7 h-7 rounded-full bg-accent/15 text-accent flex items-center justify-center shrink-0">
                    <Zap className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <p className="font-semibold text-label text-xs">จัดส่งอัตโนมัติ</p>
                    <p className="text-xs text-label-2">หลังชำระเงินสำเร็จ</p>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-surface-2 border border-separator flex items-center sm:flex-col sm:items-start gap-2">
                  <div className="w-7 h-7 rounded-full bg-success/15 text-success flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <p className="font-semibold text-label text-xs">รับประกันสินค้า</p>
                    <p className="text-xs text-label-2">ตรวจสอบก่อนส่งมอบ</p>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-surface-2 border border-separator flex items-center sm:flex-col sm:items-start gap-2">
                  <div className="w-7 h-7 rounded-full bg-warning/15 text-warning flex items-center justify-center shrink-0">
                    <Wallet className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <p className="font-semibold text-label text-xs">เติมเงินสะดวก</p>
                    <p className="text-xs text-label-2">ตรวจสลิปอัตโนมัติ</p>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => handleAction('home')}
                  className="py-2.5 px-4 rounded-full bg-accent hover:bg-accent-hover text-white font-medium text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-all shadow-sm active:scale-95 cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4 shrink-0" />
                  <span>เลือกชมสินค้า</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={() => handleAction('wallet')}
                  className="py-2.5 px-4 rounded-full bg-surface-2 hover:bg-surface border border-separator text-label font-medium text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer"
                >
                  <Wallet className="w-4 h-4 text-link shrink-0" />
                  <span>เติมเงินวอลเล็ท</span>
                </button>
              </div>
            </div>

            {/* Bottom Controls (Don't show checkbox & Close) */}
            <div className="px-5 py-3.5 bg-surface-2/60 border-t border-separator flex items-center justify-between text-xs">
              <label className="flex items-center gap-2 cursor-pointer group">
                <div className="relative flex items-center justify-center">
                  <input
                    type="checkbox"
                    className="sr-only"
                    checked={dontShow}
                    onChange={(e) => setDontShow(e.target.checked)}
                  />
                  <div className={`w-4 h-4 rounded-md border transition-all flex items-center justify-center ${dontShow ? 'bg-accent border-accent text-white' : 'bg-surface border-separator group-hover:border-label-3'}`}>
                    {dontShow && <Check className="w-3 h-3 text-white" />}
                  </div>
                </div>
                <span className="text-label-2 group-hover:text-label text-xs select-none transition-colors">
                  ไม่ต้องแสดงอีกใน 24 ชั่วโมง
                </span>
              </label>

              <button
                type="button"
                onClick={handleClose}
                className="text-xs font-medium text-label-2 hover:text-label transition-colors cursor-pointer"
              >
                ปิดหน้าต่าง
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default PopupBanner;
